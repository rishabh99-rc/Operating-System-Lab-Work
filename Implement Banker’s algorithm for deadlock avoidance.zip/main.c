/* Reg.No : 201900307 (Rishabh Chauhan)

Banker’s algorithm comprises of two algorithms:
1. Safety algorithm:
The algorithm for finding out whether or not a system is in a safe state can be described as follows: 

Step 1) Let Work and Finish be vectors of length ‘m’ and ‘n’ respectively. 
    Initialize: Work = Available 
    Finish[i] = false; for i=1, 2, 3, 4….n

Step 2) Find an i such that both 
    a) Finish[i] = false 
    b) Needi <= Work 
    if no such i exists goto step (4)
    
Step 3) Work = Work + Allocation[i] 
    Finish[i] = true 
    goto step (2)
    
Step 4) if Finish [i] = true for all i 
    then the system is in a safe state 
    
2. Resource request algorithm:
Let Requesti be the request array for process Pi. Requesti [j] = k means process Pi wants k instances of resource type Rj. When a request for resources is made by process Pi, the following actions are taken:
 

Step 1) If Requesti <= Needi 
    Goto step (2) ; 
    otherwise, raise an error condition, since the process has exceeded its maximum claim.

Step 2) If Requesti <= Available 
    Goto step (3); 
    otherwise, Pi must wait, since the resources are not available.

Step 3) Have the system pretend to have allocated the requested resources to process Pi by modifying the state as 
    follows: 
    Available = Available – Requesti 
    Allocationi = Allocationi + Requesti 
    Needi = Needi– Requesti
*/


#include <stdio.h>
int main()
{	 	  	 	   	      	    	  	 	
    // P0, P1, P2, P3, P4 are the Process names here
  
    int n, m, i, j, k;
    n = 5; // Number of processes
    m = 3; // Number of resources
    int alloc[5][3] = { { 0, 1, 0 }, // P0    // Allocation Matrix
                        { 2, 0, 0 }, // P1
                        { 3, 0, 2 }, // P2
                        { 2, 1, 1 }, // P3
                        { 0, 0, 2 } }; // P4
  
    int max[5][3] = { { 7, 5, 3 }, // P0    // MAX Matrix
                      { 3, 2, 2 }, // P1
                      { 9, 0, 2 }, // P2
                      { 2, 2, 2 }, // P3
                      { 4, 3, 3 } }; // P4
  
    int avail[3] = { 3, 3, 2 }; // Available Resources
  
    int f[n], ans[n], ind = 0;
    for (k = 0; k < n; k++) {
        f[k] = 0;
    }
    int need[n][m];
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++)
            need[i][j] = max[i][j] - alloc[i][j];
    }
    int y = 0;
    for (k = 0; k < 5; k++) {
        for (i = 0; i < n; i++) {
            if (f[i] == 0) {
  
                int flag = 0;
                for (j = 0; j < m; j++) {
                    if (need[i][j] > avail[j]){	 	  	 	   	      	    	  	 	
                        flag = 1;
                         break;
                    }
                }
  
                if (flag == 0) {
                    ans[ind++] = i;
                    for (y = 0; y < m; y++)
                        avail[y] += alloc[i][y];
                    f[i] = 1;
                }
            }
        }
    }
  
    printf("Following is the SAFE Sequence\n");
    for (i = 0; i < n - 1; i++)
        printf(" P%d ->", ans[i]);
    printf(" P%d", ans[n - 1]);
  
    return (0);
  
}

/* Expected (Input/Output):--

Following is the SAFE Sequence
P1 -> P3 -> P4 -> P0 -> P2
 
*/ 	 	  	 	   	      	    	  	 	
