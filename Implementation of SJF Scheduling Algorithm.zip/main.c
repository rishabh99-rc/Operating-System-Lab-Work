/*
Name : Rishabh Chauhan
Registration : 201900307

ALGORITHM:
STEP 0: Start.
STEP 1: Declaring File pointer name fp1 and fp2.
STEP 2 : Declare a integer variable named number_of_process , sum , and float varaible named avg.
STEP 3 : Read number_of_process.
STEP 4 : number_of_process++.
STEP 5 : Declaring array of size number_of_process.
STEP 6 : for i=0 to number_of_process
            arr[i] = 0
STEP 7 : Display " Enter Execution Time : "
STEP 8 : for i=0 to number_of_process
            Read arr[i]
STEP 9 : Opening file named in.txt in write mode and storing the address in pointer fp1.
STEP 10: Printing Exceution Time and process in file. fp1
STEP 11: Closing File fp1.
STEP 12: Opening file named out.txt in write mode and storing the address in pointer fp1.
STEP 13: Printing Gantt Chart.
STEP 14: Printing Process Time for each Process.
STEP 15: Printing Average Waiting Time.
STEP 16: Stop.
*/

#include <stdio.h>

int main()
{
    FILE *fp1, *fp2;
    int n = 0;
    int sum = 0;
    float avg = 0;
    printf("Enter the number of processes: ");
    scanf("%d", &n);

    n++;
    int arr[n];
    int process[n];

    for (int i = 0; i < n; i++)
    {	 	  	 	    	   	   	  	 	
        arr[i] = 0;
    process[i] = i;
    }

    printf("Enter the execution time for each process: \n");
    for (int i = 1; i < n; i++)
    {
        printf("Process J%d - ", i);
        scanf("%d", &arr[i]);
    }

    fp1 = fopen("in.txt", "w");
    fprintf(fp1, "Process Name\t\tExecution Time\n");
    for (int i = 1; i < n; i++)
    {
        fprintf(fp1, "\t%d\t\t\t\t\t%d\n", i, arr[i]);
    }
    fclose(fp1);

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] > arr[j])
            {
                int t = arr[i];
                arr[i] = arr[j];
                arr[j] = t;

                int a = process[i];
                process[i] = process[j];
                process[j] = a;
            }
        }
    }

    for (int i = 0; i < n - 1; i++)
    {	 	  	 	    	   	   	  	 	
        arr[i + 1] += arr[i];
    }
    printf("\n");

    fp2 = fopen("out.txt", "w");
    fprintf(fp2, "Gantt Chart:\n");
    fprintf(fp2, "|");
    printf("Gantt Chart:\n");
    printf("|");
    for (int i = 0; i < n - 1; i++)
    {
        printf("------J%d-------|", process[i+1]);
        fprintf(fp2, "------J%d-------|", process[i + 1]);
    }
    printf("\n");
    fprintf(fp2, "\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d\t", arr[i]);
        printf("\t");
        fprintf(fp2, "%d\t\t\t", arr[i]);
        fprintf(fp2, "\t");
    }
    printf("\n");
    printf("\nWaiting Time for each Process :\n");
    fprintf(fp2, "\n\nWaiting Time for each Process :\n");
    for (int i = 0; i < n - 1; i++)
    {
        fprintf(fp2, "J%d = %d\n", process[i + 1], arr[i]);
        printf("J%d = %d\n", process[i + 1], arr[i]);
    }

    for (int i = 0; i < n - 1; i++)
    {
        sum += arr[i];
    }	 	  	 	    	   	   	  	 	

    printf("\n");
    fprintf(fp2, "\n");
    avg = sum / (float)(n - 1);
    fprintf(fp2, "The Average Waiting Time is : %f", avg);
    printf("The Average Waiting Time is : %f", avg);

    fclose(fp2);
    return 0;
}

/*
Input/Output
-------------
Enter the number of processes: 3                                                
Enter the execution time for each process:                                      
Process J1 - 5                                                                  
Process J2 - 2                                                                  
Process J3 - 1                                                                  
                                                                                
Gantt Chart:                                                                    
|------J3-------|------J2-------|------J1-------|                               
0               1               3               8                               
                                                                                
Waiting Time for each Process :                                                 
J3 = 0                                                                          
J2 = 1                                                                          
J1 = 3                                                                          
                                                                                
The Average Waiting Time is : 1.333333                                          
                                        
*/	 	  	 	    	   	   	  	 	
