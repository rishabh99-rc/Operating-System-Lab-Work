/*
Name:-Rishabh Chauhan
Registration Number:-201900307

ALGORITHM: 

Step 1:  Start.
Step 2:  Create a function to calculate the waiting time of processes.
Step 3: To calulate  the wait time for i-th process, add the the previous wait time and the burst time
        (the wait time for the first process will be 0 because it will start right from the beginning).
Step 4:  Create a function, which displays the result, also prints it in the text file and calls the waiting process. It takes process, n and the burst time of the process as input.
Step 5: Once it has received the required parameters from the main , pass it to the waiting_Time function to calculate it.   
Step 6 : Calculate the average wait time and display all the results on the console.
Step 7: Open a text file in write mode and write same on the file what was displayed on console. And close the file then.
Step 8: In the main function, ask the user for the burst time of the different processes. 
Step 9: calculate n and pass everything to the display function.
Step 10:  Open a file in write mode and write the user input there.
Step 11:  Close the file.
Step 12: Stop
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int num;
  printf("Enter The Total Number of Process to Deal with:-");
  scanf("%d",&num);
  FILE *ptr,*ptr1;  //file pointers
  printf("Enter The the Process Execution Time:-\n");
  int ext[num];
  for(int i=0;i<num;i++)
  {
    printf("P[%d]:",i+1);
    scanf("%d",&ext[i]);
  }	 	  	 	   	      	    	  	 	
  ptr=fopen("input.txt","w");    //input file
  ptr1=fopen("output.txt","w");  //output file
  if(!ptr)
  {
    printf("File Open Failure");
    exit(1);
  }
  else
  {
    fprintf(ptr,"Process Name  Execution Time\n");
    for(int i=0;i<num;i++)
    {
      fprintf(ptr,"P[%d]:         %d\n",i+1,ext[i]);
    }
  }
  //Gantt Chart Maker
  int processt[num+1];
  float wait=0;
  processt[0]=0;
  for(int i=1;i<num;i++)
  {
    processt[i]=0;
    for(int j=0;j<i;j++)
    {
      processt[i]+=ext[j];
    }
  }
  //Last Process Entry
  processt[num]=0;
  processt[num]=processt[num-1]+ext[num-1];
  //Avg Wait Time
  for(int i=0;i<num;i++)
  {
    wait+=processt[i];
  }
  //Console output
  printf("\nGantt Chart\n");
  fprintf(ptr1,"Gantt Chart\n");
  for(int i=0;i<num;i++)
  {	 	  	 	   	      	    	  	 	
    printf("|----J[%d]----",i+1);
    fprintf(ptr1,"|----J[%d]----",i+1);
  }
  printf("|\n");
  fprintf(ptr1,"|\n");
  for(int i=0;i<num;i++)
  {
    printf("%d           ",processt[i]);
    fprintf(ptr1,"%d           ",processt[i]);
  }
  printf("%d",processt[num]);
  fprintf(ptr1,"%d           ",processt[num]);
  printf("\n\n");
  //Waiting Time Output
  printf("Waiting Time For Each Process:\n");
  fprintf(ptr1,"Waiting Time For Each Process:\n");
  for(int i=0;i<num;i++)
  {
    printf("J[%d]:%d\n",i+1,processt[i]);
    fprintf(ptr1,"J[%d]:%d\n",i+1,processt[i]);
  }
  //Average Waiting Time
  printf("Average Waiting Time:->%.2f",(float)wait/num);
  fprintf(ptr1,"Average Waiting Time:->%.2f",(float)wait/num);
  fclose(ptr);
  fclose(ptr1);
  return 0;
}
/*
I/O-

Enter The Total Number of Process to Deal with:-4                               
Enter The the Process Execution Time:-                                          
P[1]:15                                                                         
P[2]:8                                                                          
P[3]:10                                                                         
P[4]:3                                                                          
                                                                                
Gantt Chart                                                                     
|----J[1]----|----J[2]----|----J[3]----|----J[4]----|                           
0           15           23           33           36                           
                                                                                
Waiting Time For Each Process:                                                  
J[1]:0                                                                          
J[2]:15                                                                         
J[3]:23                                                                         
J[4]:33                                                                         
Average Waiting Time:->17.75                                                    
*/	 	  	 	   	      	    	  	 	
