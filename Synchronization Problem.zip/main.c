/*  Reg.No: 201900307 (Rishabh Chuahan)

*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <semaphore.h>
#include <unistd.h>

#define HACKER 0
#define SERF 1

typedef struct{
    pthread_mutex_t mutex;      
    pthread_barrier_t barrier;  
    int n_hackers;   
    int n_serfs;     
    int cap;         
    sem_t hackers_queue;   
    sem_t serfs_queue;      
} Boat;


void * board(void *a);
void row_boat(pthread_mutex_t * mutex, int * is_captain, sem_t * queue, const int cap);
void print_boat_fleet(const Boat boat);

struct pthread_board{
    Boat * boat;
    int is_captain;
    int type;
};


void * board(void *a){	 	  	 	   	      	    	  	 	
    struct pthread_board * args = (struct pthread_board *)a;
    if(args->type == SERF){
        args->boat->n_serfs++;
        sem_post(&args->boat->serfs_queue);
        if(args->boat->n_serfs == args->boat->cap){
            print_boat_fleet(*args->boat);
            pthread_barrier_wait(&(args->boat->barrier));   
            args->is_captain = 1;   
            pthread_mutex_lock(&args->boat->mutex);
            row_boat(&args->boat->mutex, &args->is_captain, &args->boat->serfs_queue, args->boat->cap);
            args->boat->n_serfs = 0;
        }
        else if (args->boat->n_hackers == args->boat->cap/2 && args->boat->n_serfs == args->boat->cap/2){
            print_boat_fleet(*args->boat);
            pthread_barrier_wait(&(args->boat->barrier));    
            args->is_captain = 1;   
            pthread_mutex_lock(&args->boat->mutex);
            row_boat(&args->boat->mutex, &args->is_captain, &args->boat->serfs_queue, args->boat->cap);
            args->boat->n_hackers = 0;
            args->boat->n_serfs = 0;
        }
        else{
            if(args->boat->n_hackers + args->boat->n_serfs >= args->boat->cap){
                args->boat->n_serfs--;
            }
            else{
                print_boat_fleet(*args->boat);
                pthread_barrier_wait(&(args->boat->barrier));    
                pthread_mutex_unlock(&(args->boat->mutex));
            }
        }
        sem_wait(&args->boat->serfs_queue);           
    }
    else{
        args->boat->n_hackers++;
        sem_post(&args->boat->hackers_queue);
        if(args->boat->n_hackers == args->boat->cap){	 	  	 	   	      	    	  	 	
            print_boat_fleet(*args->boat);
            pthread_barrier_wait(&(args->boat->barrier));    
            args->is_captain = 1;   
            pthread_mutex_lock(&args->boat->mutex);
            row_boat(&args->boat->mutex, &args->is_captain, &args->boat->hackers_queue, args->boat->cap);
            args->boat->n_hackers = 0;
        }
        else if (args->boat->n_hackers == args->boat->cap/2 && args->boat->n_serfs == args->boat->cap/2){
            print_boat_fleet(*args->boat);
            pthread_barrier_wait(&(args->boat->barrier));   
            args->is_captain = 1;   
            pthread_mutex_lock(&args->boat->mutex);
            row_boat(&args->boat->mutex, &args->is_captain,&args->boat->hackers_queue, args->boat->cap);
            args->boat->n_serfs = 0;
            args->boat->n_hackers = 0;
        }
        else{
            if(args->boat->n_hackers + args->boat->n_serfs >= args->boat->cap){
                args->boat->n_hackers--;
            }
            else{
                print_boat_fleet(*args->boat);
                pthread_barrier_wait(&(args->boat->barrier));   
                pthread_mutex_unlock(&(args->boat->mutex));
            }
        }
        sem_wait(&args->boat->hackers_queue);             
    }
}; 

void row_boat(pthread_mutex_t * mutex, int * is_captain, sem_t * queue, const int cap){
    int i;
    printf("Row!!\n");
    sleep(5);               
    printf("Unload!!\n\n");   
    sleep(5);               
    pthread_mutex_unlock(mutex);
    for(i=0;i<cap;i++) sem_post(queue);
                          
    *is_captain = 0;
};

void print_boat_fleet(const Boat boat){	 	  	 	   	      	    	  	 	
    printf("h: %d, s: %d\n", boat.n_hackers, boat.n_serfs);
}


int main(){
    system("clear");
    printf("River Crossing problem.\n\n");
    printf("You can terminate the execution of the program at any time by pressing the Ctrl + C keys on the keyboard.\n\n");
    sleep(15);
    system("clear");
    sleep(5);
    srand(time(NULL)); 
    int is_captain;
    Boat boat;
    pthread_t person;
    is_captain = 0;
    // initialize boat with standard configuration
    boat.cap = 4;
    boat.n_hackers = 0;
    boat.n_serfs = 0;
    pthread_barrier_init(&(boat.barrier), NULL, 4);
    pthread_mutex_init(&(boat.mutex), NULL);
    pthread_mutex_lock(&(boat.mutex));
    sem_init(&boat.hackers_queue, 0, 0);        
    sem_init(&boat.serfs_queue, 0, 0);      
    struct pthread_board args;
    args.boat = &boat;
    args.is_captain = is_captain;
    // Creating threads
    while(1){
        sleep(1);
        int person_type = random() % 2; // with random type (HACKER or SERF)
        args.type = person_type;
        pthread_create(&person,NULL, board,(void *)&args);
    }
    pthread_join(person, NULL);
    return 0;
}	 	  	 	   	      	    	  	 	