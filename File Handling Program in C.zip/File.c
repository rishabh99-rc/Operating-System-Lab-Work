/*
    Reg.No: 201900307
    Source file: source.txt
    Destination file: dest.txt
    
Algorithm:-->

Step 1: Start

Step 2: Input file path of source and destination file.

Step 3: Open source file in r (read) and destination file in w (write) mode.

Step 4: Read character from source file and write it to destination file using fputc().

Step 5: Repeat step 4 till source file has reached end.

Step 6: Close both source and destination file.

Step 7: Stop
*/

/*  Expected (Input/Output) :--

Enter source file path: source.txt                                              
Enter destination file path: dest.txt                                           
                                                                                
Files copied successfully.                                                      
84 characters copied.                                                           

*/

/**
 * C program to copy contents of one file to another using functions.
 */

#include <stdio.h>
#include <stdlib.h>


/* File copy function declaration */
int fcpy(FILE * sourceFile, FILE * destFile);


int main()
{	 	  	 	   	      	    	  	 	
    FILE *sourceFile;
    FILE *destFile;
    char sourcePath[100];
    char destPath[100];

    int count;


    /* Input path of files to copy */
    printf("Enter source file path: ");
    scanf("%s", sourcePath);
    printf("Enter destination file path: ");
    scanf("%s", destPath);

    /* 
     * Open source file in 'r' and 
     * destination file in 'w' mode 
     */
    sourceFile  = fopen(sourcePath, "r");
    destFile    = fopen(destPath,   "w");

    /* fopen() return NULL if unable to open file in given mode. */
    if (sourceFile == NULL || destFile == NULL)
    {
        /* Unable to open file hence exit */
        printf("\nUnable to open file.\n");
        printf("Please check if file exists and you have read/write privilege.\n");

        exit(EXIT_FAILURE);
    }


    // Call function to copy file
    count = fcpy(sourceFile, destFile);
    printf("\nFiles copied successfully.\n");
    printf("%d characters copied.\n", count);


    /* Finally close files to release resources */
    fclose(sourceFile);
    fclose(destFile);

    return 0;
}	 	  	 	   	      	    	  	 	



/**
 * Copy file contents character by charcter from 
 * one file to another. 
 * It return total character copied count.
 * 
 * @sourceFile  Pointer to source FILE.
 * @destFile    Pointer to destination FILE.
 */ 
int fcpy(FILE * sourceFile, FILE * destFile)
{
    int  count = 0;
    char ch;

    /* Copy file contents character by character. */
    while ((ch = fgetc(sourceFile)) != EOF)
    {
        fputc(ch, destFile);

        /* Increment character copied count */
        count++;
    }

    return count;
}	 	  	 	   	      	    	  	 	
