/*  Reg.No: 201900307 (Rishabh Chauhan)
step 0: Start
step 1: void Sorting(int n,int p[],int at[], int bt[]){
    step 1.1: int i,min,k=1,btime=0;
    step 1.2: int temp,j;
    step 1.3: for(i=0;i<n;i++)
        step 1.3.1: for(j=0;j<n;j++)
            step 1.3.1.1: if(at[i]<at[j])
    step 1.4: for(j=0;j<n;j++)
        step 1.4.1: for(i=k;i<n;i++)
            step 1.4.1.1: if (btime>=at[i] && bt[i]<min)
step 2: float WaitingTime(int n,int wt[], int bt[],int at[], int ct[]) {
    step 2.1: int sum=0,i;
    step 2.2: float wavg=0,wsum=0;
    step 2.3: for(i=1;i<n;i++)
    step 2.4: for(i=1;i<n;i++)
    step 2.5: return wavg;
step 3: void StoreInFile(int p[], int bt[], int at[], int wt[], int n, float wavg, int ct[]) {
    step 3.1: int i;
    step 3.2: FILE *fp2;
    step 3.3: fp2 = fopen("output.txt","w");
    step 3.4: for(i=0;i<n;i++)
    step 3.5: for(i=0;i<n;i++)
step 4: void Output(int p[], int bt[], int at[], int wt[], int n, float wavg, int ct[]) {
    step 4.1: int i;
    step 4.2: display "RESULT"
    step 4.3: display "Process\t Burst\t Arrival\t Waiting"
    step 4.4: for(i=0;i<n;i++)
    step 4.5: display "AVERAGE WAITING TIME :"
    step 4.6: display "Gantt chart: "
    step 4.7: for(i=0;i<n;i++)
step 5: int main()
    step 5.1: int p[4], bt[4], at[4], ct[4], wt[4], n;
    step 5.2: float wavg;
    step 5.3: FILE *fp;
    step 5.4: int i;
    step 5.5: for(i =0; i<n; i++) 
    step 5.6: for(i =0; i<n; i++) 
    step 5.7: for(i =0; i<n; i++) 
    step 5.8: Sorting(n,p,at,bt);
    step 5.9: wavg = WaitingTime(n,wt,bt,at,ct);
    step 5.10: Output(p, bt, at,wt,n,wavg,ct);
    step 5.11: StoreInFile(p, bt, at,wt,n,wavg,ct);
    step 5.12: return 0;
step 6: Stop
*/

// PROGRAM
#include<stdio.h>


void Sorting(int n,int p[],int at[], int bt[]){	 	  	 	   	      	    	  	 	
    // Sorting According to Arrival Time
    int i,min,k=1,btime=0;
    int temp,j;

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(at[i]<at[j])
            {
                temp=p[j];
                p[j]=p[i];
                p[i]=temp;
                temp=at[j];
                at[j]=at[i];
                at[i]=temp;
                temp=bt[j];
                bt[j]=bt[i];
                bt[i]=temp;
            }
        }
    }

    // Arranging the table according to Burst time, Execution time and Arrival Time
    for(j=0;j<n;j++)
    {
        btime=btime+bt[j];
        min=bt[k];
        for(i=k;i<n;i++)
        {
            if (btime>=at[i] && bt[i]<min)
            {
                temp=p[k];
                p[k]=p[i];
                p[i]=temp;
                temp=at[k];
                at[k]=at[i];
                at[i]=temp;
                temp=bt[k];
                bt[k]=bt[i];
                bt[i]=temp;
            }	 	  	 	   	      	    	  	 	
        }
        k++;
    }
}

float WaitingTime(int n,int wt[], int bt[],int at[], int ct[]) {
    // For calculation of Waiting time of each process
    int sum=0,i;
    float wavg=0,wsum=0;

    wt[0]=0;
    for(i=1;i<n;i++)
    {
        sum=sum+bt[i-1];
        wt[i]=sum-at[i];
        wsum=wsum+wt[i];
    }

    wavg=(wsum/n); // average waiting time

    ct[0] = bt[0];
    for(i=1;i<n;i++)
    {
        ct[i]=ct[i-1]+bt[i];
    }

    return wavg;
}

void StoreInFile(int p[], int bt[], int at[], int wt[], int n, float wavg, int ct[]) {
    // Storing Output in a file (output.txt)
    int i;
    FILE *fp2;
    fp2 = fopen("output.txt","w");

    fputs("Process\t Burst\t Arrival\t Waiting",fp2);
    for(i=0;i<n;i++)
    {	 	  	 	   	      	    	  	 	
        fprintf(fp2,"\n p%d\t\t %d\t\t %d\t\t\t %d",p[i],bt[i],at[i],wt[i]);
    }

    fprintf(fp2,"\n\nAVERAGE WAITING TIME : %.2f",wavg);

    fprintf(fp2,"\n\nGantt chart: 0");
    for(i=0;i<n;i++)
    {
        fprintf(fp2," p%d %d",p[i],ct[i]);
    }

    fclose(fp2);
}

void Output(int p[], int bt[], int at[], int wt[], int n, float wavg, int ct[]) {
    // Displaying Output On Console
    int i;
    printf("\nRESULT");
    printf("\nProcess\t Burst\t Arrival\t Waiting" );
    for(i=0;i<n;i++)
    {
        printf("\n p%d\t %d\t %d\t\t %d",p[i],bt[i],at[i],wt[i]);
    }

    printf("\n\nAVERAGE WAITING TIME : %.2f",wavg);

    printf("\n\nGantt chart: 0");
    for(i=0;i<n;i++)
    {
        printf(" p%d %d",p[i],ct[i]);
    }
}

int main()
{
    int p[4], bt[4], at[4], ct[4], wt[4], n;
    float wavg;

    // Reading input from file (input.txt)
    FILE *fp;
    int i;
    fp = fopen("input.txt", "r");

    fscanf(fp, "%d", &n);
    for(i =0; i<n; i++) {	 	  	 	   	      	    	  	 	
        fscanf(fp, "%d", &p[i]);
    }
    for(i =0; i<n; i++) {
        fscanf(fp, "%d", &bt[i]);
    }
    for(i =0; i<n; i++) {
        fscanf(fp, "%d", &at[i]);
    }

    fclose(fp);

    Sorting(n,p,at,bt);
    wavg = WaitingTime(n,wt,bt,at,ct);
    Output(p, bt, at,wt,n,wavg,ct);
    StoreInFile(p, bt, at,wt,n,wavg,ct);

    return 0;
}

/*
CONTENT OF INPUT FILE (input.txt)
    4
    1 2 3 4
    7 4 1 4
    0 2 4 5
    (n, p[], bt[], at[] respectively)

FINAL CONTENT OF OUTPUT FILE (output.txt)
    Process	 Burst	 Arrival	 Waiting
     p1		 7		 0			 0
     p3		 1		 4			 3
     p2		 4		 2			 6
     p4		 4		 5			 7

    AVERAGE WAITING TIME : 4.00

    Gantt chart: 0 p1 7 p3 8 p2 12 p4 16
 */	 	  	 	   	      	    	  	 	
