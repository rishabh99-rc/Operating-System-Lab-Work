/*
Name: Rishabh Chauhan
Regn no: 201900307

Algorithm:

Step 1: Start

Step 2: At time 0, process P1 arrives in the ready queue and executes its tasks for time quantum 6 units. 
        During 6 units of the time slice, another process P2, P3 and P4 arrive in the ready queue. 
        After that, process P1 will return to the end of the ready queue and await their execution.

Step 2: Now, process P2 starts their execution for time slot 5 units because the Burst Time (BT) is 5, 
        and it does not go to the ready queue for further execution.


Step 3: After that process, P3 will start its execution, which has 10 Burst time, but the time quantum 
        is 6 units. Therefore, it executes its tasks for a defined time limit and is added to the ready 
        queue's end.

Step 4: After that, the process P4 starts their execution, which has burst time 11, but the time quantum 
        is 6 units. It executes its tasks for only 6 seconds and then adds to the end of the ready queue.

Step 5: After the execution of P4, now P1 will start its execution again for 2 units or second, and the 
        process P1 terminate or end. Similarly, the complete execution of process P1, then P3, starts its 
        remaining execution for Burst Time 4, and the process is completed.

Step 6: After the complete execution of process P3, now process P4 executes for the remaining time slot, 
        which is 5, and the process is finished.

*/

#include<stdio.h>
#include<stdbool.h>
 
struct times
{	 	  	 	   	      	    	  	 	
       int p,burst_time,wait_time,rem_time; 
};

int main()
{
       /* FILE *fp1; */
       /*fp1 = fopen("Input.txt","w"); */
       int i,j,pro,time=0,ts;
       struct times a[100];
       float total_wt=0;
       printf("Round Robin Scheduling Algorithm\n");
       printf("Enter Number Of Processes : ");
       scanf("%d",&pro);
       /* fprintf(fp1,"Enter Number Of Processes : %d",n);*/
       for(i=0;i<pro;i++)
       {
              printf("Enter Burst time for Process P %d : ",i);
              scanf("%d",&a[i].burst_time);
              /* fprintf(fp1,"Enter Burst time for Process P %d : %d",i,a[i].burst_time);*/
              
              a[i].p = i;
              a[i].rem_time = a[i].burst_time;
       }
       
       printf("Enter Time Slice OR Quantum Number : ");
       scanf("%d",&ts);
       /* fprintf(fp1,"Enter Time Slice OR Quantum Number : %d",ts); */
       /* fprintf("\n"); */

       printf("\n\nGantt Chart\n");
       /* fprintf(fp1,"Gantt Chart"); */
       printf("0");
       /* fprintf(fp1,"0"); */
       while(1){
         bool done=true;
         for(i=0;i<pro;i++)
         {	 	  	 	   	      	    	  	 	
            if(a[i].rem_time>0){
                done=false;
                if(a[i].rem_time<=ts )
                {
                     time = time + a[i].rem_time;
                     a[i].wait_time=time-a[i].burst_time;
                     printf("|-----P%d----- %d",a[i].p,time);
                     /* fprintf(fp1,"|-----P%d----- %d",a[i].p,time); */
                     a[i].rem_time=0;
                }
                else 
                {
                     
                     a[i].rem_time = a[i].rem_time - ts;
                     time = time + ts;
                     printf("|-----P%d-----%d",a[i].p,time);
                     /* fprintf(fp1,"|-----P%d----- %d",a[i].p,time); */
                }
            } 
         }
         if(done==true)break;
       }
       
       for (i=0; i<pro; i++)
       {
          total_wt = total_wt + a[i].wait_time;
       }
       printf("\n\n");
       printf("***\n");
       /* fprintf(fp1,"*"); */
       printf("Process\tBurst Time\tWaiting Time\n");
       /* fprintf(fp1,"Pro\tburst_timei\twait_timei\n"); */
       printf("***\n");
       /* fprintf(fp1,"*") */
       for(i=0;i<pro;i++)
       {	 	  	 	   	      	    	  	 	
              printf("P%d\t\t\t%d\t\t\t%d\n",a[i].p,a[i].burst_time,a[i].wait_time);
              /* fprintf(fp1,"P%d\t%d\t%d\n",a[i].p,a[i].burst_time,a[i].wait_time); */
       }
       printf("***\n\n");
       /* fprintf(fp1,"*\n\n"); */
       double avgwt = total_wt/pro;
       printf("Average Waiting Time : %.2f\n",avgwt);
       /* fprintf(fp1,"Average Waiting Time : %.2f\n",avgwt);*/
       return 0;
}


/*

Expected I/O:

Total number of process in the system: 4

Enter the Arrival and Burst time of the Process[1]
Arrival time is:    0

Burst time is:  8

Enter the Arrival and Burst time of the Process[2]
Arrival time is:    1

Burst time is:  5

Enter the Arrival and Burst time of the Process[3]
Arrival time is:    2

Burst time is:  10

Enter the Arrival and Burst time of the Process[4]
Arrival time is:    3

Burst time is:  11

Enter the Time Quantum for the process:     6

Process No      Burst Time      TAT     Waiting Time

Process No[2]       5           10          5
Process No[1]       8           25          17
Process No[3]       10          27          17
Process No[4]       11          31          20


Gantt Chart:

|--P1--|--P1--|--P3--|--P4--|--P1--|--P3--|--P4--|
0      6      11     17     23    25    29    34


Average Turn Around Time:   14.750000
Average Waiting Time:   23.250000


*/	 	  	 	   	      	    	  	 	
